// +build tools

package tools

import (
	_ "github.com/tailscale/depaware" // required by rules.mk
)
