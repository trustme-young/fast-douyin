

```
export COS_SECRETID=xx
export COS_SECRETKEY=xxx

go run xxx.go
```
